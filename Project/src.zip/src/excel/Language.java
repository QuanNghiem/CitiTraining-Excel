package excel;

public class Language extends Subject {

    public Language(Double value) {
        super(value);
    }

    public Double getValue() {
        return super.getValue();
    }
}