package excel;

public class Math extends Subject {

    public Math(Double value) {
        super(value);
    }

    public Double getValue() {
        return super.getValue();
    }
}
