package excel;

public interface SubjectInterface {
    public Double getValue();
}
